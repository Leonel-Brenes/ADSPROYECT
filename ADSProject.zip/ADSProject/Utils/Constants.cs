﻿namespace ADSProject.Utils
{
    public class Constants
    {
        public const string COD_EXITO = "000000";
        public const string COD_ERROR = "999999";
    }
}
